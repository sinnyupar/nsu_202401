package no1;

public class No5 {
	public static void main(String[] args) {
      
        char c = 'a';
        
        // Convert lowercase to uppercase using ASCII values
        int diff = (int) 'A' - (int) 'a'; // Calculate the difference between uppercase and lowercase ASCII values
        char upperCaseC = (char) ((int) c + diff); // Add the difference to convert lowercase to uppercase
        
        // Print the result
        System.out.println("Original lowercase character: " + c);
        System.out.println("Uppercase character: " + upperCaseC);
    }

}
