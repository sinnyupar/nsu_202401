package no1;
import java.util.Scanner;
public class No4 {
	public static void main(String[]args) {
		Scanner in = new Scanner(System.in);
		 System.out.print("초 단위 정수를 입력하세요 ");
		 int x = in.nextInt();
		 int hour = x / 3600;
		 int remainingSec = x % 3600;
		 int minute = remainingSec / 60;
		 int second = remainingSec % 60;
		 
		 System.out.println(hour +"시간" + minute + "분" + second + "초");
	}

}
