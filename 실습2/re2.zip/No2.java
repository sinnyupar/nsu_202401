package no1;
import java.util.Scanner;
public class No2 {
	 public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		 System.out.print("정수를 입력하세요: ");
		 int x = in.nextInt();
		 int y = x * x;
		 System.out.println(x + "의 제곱은"+ y +"입니다");
		 
	 }
}
